package com.pimay.sagec_mov;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sigac_mov.R;
import com.sigac.tools.BaseActivity;
import com.sigac.tools.Handler_sqlite;

public class MntTelefonmo extends BaseActivity {
	Handler_sqlite helper=null;
	private ArrayList<HashMap<String, String>> myItems = new ArrayList<HashMap<String, String>>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.mnt_telefono);
		helper= new Handler_sqlite(this);
		helper.abrir();
		Log.i("LocAndroid Response HTTP Threads ", "Abriendo Helper");						
		Spinner s1 = (Spinner)findViewById(R.id.spinner1);		
		List<String> array_spinner1= helper.lista_tabla_tablas("4");		
		helper.cerrar(); 				
		//----
		ArrayAdapter adapter1 = new ArrayAdapter(this,android.R.layout.simple_spinner_item, array_spinner1);
		adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		s1.setAdapter(adapter1);					
	}	
	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	    	MenuInflater inflater = getMenuInflater();
	    	inflater.inflate(R.menu.menu_grabar, menu);
	        return true;
	    }	    
	 @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        // Handle item selection
	        switch (item.getItemId()) {
	            case R.id.OpcGrabar:
	            	//--- grabar telefono 
	            	
	            	return true;	                        
	            default:
	                return super.onOptionsItemSelected(item);
	        }
	    }
}


