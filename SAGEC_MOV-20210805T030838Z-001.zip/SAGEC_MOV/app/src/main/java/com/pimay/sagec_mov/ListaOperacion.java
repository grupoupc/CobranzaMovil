package com.pimay.sagec_mov;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sigac_mov.R;
import com.sigac.tools.BaseActivity;
import com.sigac.tools.Handler_sqlite;

public class ListaOperacion extends BaseActivity {
	Handler_sqlite helper=null;
	private ArrayList<HashMap<String, String>> myItems = new ArrayList<HashMap<String, String>>();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.detalle_oper);
		populateListView();			
	}	
	private void populateListView() {
		Bundle bundle = this.getIntent().getExtras();                
		helper= new Handler_sqlite(this);
		helper.abrir();		
		myItems = helper.leerRegOperacion(bundle.getString("id_cliente").toString());
		helper.cerrar();
		ListView list = (ListView) findViewById(R.id.ListView1);
	//	SimpleAdapter mSchedule = new SimpleAdapter(this, myItems, R.layout.da_oper,
	//            new String[] {"itemOperacion", "itemDescripcion"}, new int[] {R.id.itemOperacion, R.id.itemDescripcion});
	//	list.setAdapter(mSchedule);						
	}
}

