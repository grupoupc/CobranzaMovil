package com.pimay.sagec_mov;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sigac_mov.R;
import com.sigac.tools.BaseActivity;
import com.sigac.tools.Handler_sqlite;

public class GestionClientes extends BaseActivity {
	Handler_sqlite helper=null;
	private String array_spinner1[];
	private String array_spinner2[];
	private String array_spinner3[];
	private String id_cliente;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);		
		setContentView(R.layout.gestion);
		// Here come all the options that you wish to show depending on the
		// size of the array.			
		Bundle bundle = this.getIntent().getExtras();
        String datos=bundle.getString("datos").toString();
        final TextView pdatos=(TextView)findViewById(R.id.lblDtos);
        pdatos.setText("Datos Personale: " +datos);        
		helper= new Handler_sqlite(this);
		helper.abrir();
		Log.i("LocAndroid Response HTTP Threads ", "Abriendo Helper");						
		Spinner s1 = (Spinner)findViewById(R.id.spinner1);
		Spinner s2 = (Spinner) findViewById(R.id.spinner2);
		Spinner s3 = (Spinner) findViewById(R.id.spinner3);
		List<String> array_spinner1= helper.lista_tabla_tablas("1");
		List<String> array_spinner2= helper.lista_tabla_tablas("2");
		List<String> array_spinner3= helper.lista_tabla_tablas("3");
		helper.cerrar(); 
		bundle = this.getIntent().getExtras();
        id_cliente=bundle.getString("id_cliente").toString();		
		//----
		ArrayAdapter adapter1 = new ArrayAdapter(this,android.R.layout.simple_spinner_item, array_spinner1);
		adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		s1.setAdapter(adapter1);		
		//----		
		ArrayAdapter adapter2 = new ArrayAdapter(this,android.R.layout.simple_spinner_item, array_spinner2);
		adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		s2.setAdapter(adapter2);
		//----
		ArrayAdapter adapter3 = new ArrayAdapter(this,android.R.layout.simple_spinner_item, array_spinner3);
		adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		s3.setAdapter(adapter3);				                              
	}	 
	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {
	        // Inflate the menu; this adds items to the action bar if it is present.
	    	MenuInflater inflater = getMenuInflater();
	    	inflater.inflate(R.menu.menu_gestion, menu);
	        return true;
	    }
	 @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        // Handle item selection
	        switch (item.getItemId()) {
	            case R.id.OpcTelefono:
	            	Intent telefonos=new Intent(GestionClientes.this,ListaTelefonos.class);
	            	telefonos.putExtra("id_cliente",id_cliente);
	            	startActivity(telefonos);
	            	return true;
	            case R.id.OpcDireccion:
	            	Intent direccion=new Intent(GestionClientes.this,ListaDireccion.class);
	            	direccion.putExtra("id_cliente",id_cliente);
	            	startActivity(direccion);	            	
	            	return true;
	            case R.id.OpcOperacion:
	            	Intent operacion=new Intent(GestionClientes.this,ListaOperacion.class);
	            	operacion.putExtra("id_cliente",id_cliente);
	            	startActivity(operacion);  
	            	return true;
	            case R.id.OpcPromesa:
	            	return true;
	            case R.id.OpcGestion:	
	                //newGame();	    
	            	
	                return true;            
	            default:
	                return super.onOptionsItemSelected(item);
	        }
	    }
}
