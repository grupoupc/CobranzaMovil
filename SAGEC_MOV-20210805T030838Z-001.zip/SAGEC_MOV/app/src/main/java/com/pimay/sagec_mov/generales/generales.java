package com.pimay.sagec_mov.generales;

import java.io.IOException;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;



import android.util.Log;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class generales {
		 public String httpGetData(String mURL){
		    	CargaDatosWS WS = new CargaDatosWS();
		    	String response="";
		    	String respuesta= WS.Carga();
		    	Log.i("Response HTTP Threads","Ejecutando: "+respuesta);
		    	mURL=mURL.replace(" ","%20");
		    	Log.i("Response HTTP Threads","Ejecutando: "+mURL);
			 	OkHttpClient client = new OkHttpClient();
		    	HttpClient httpclient = new DefaultHttpClient(); 
		    	Log.i("Response HTTP Threads","Ejecutando");
		    	HttpPost httppost=new HttpPost(mURL);
		    	Log.i("Response HTTP Threads","Ejecutando");
		    	try {
		    		Log.i("Response HTTP Threads","Ejecutando get");
		    		ResponseHandler<String> responseHandler=new BasicResponseHandler();
		    		response = httpclient.execute(httppost, responseHandler);
		    		Log.i("Reponse HTTP",response);
		    	} catch (ClientProtocolException e){
		    		Log.i("Reponse HTTP ERROR 2",e.getMessage());
		    	} catch (IOException e){
		    		Log.i("Reponse HTTP ERROR 2",e.getMessage());
		    	}
		    	return response;
		    }
}
