package com.pimay.sagec_mov.tools;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.sigac_mov.ListaClientes;
import com.example.sigac_mov.MainActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import static android.provider.BaseColumns._ID;
import com.sigac.tools.BaseActivity;
public class Handler_sqlite extends SQLiteOpenHelper {
	String pURL;	
	public String id_cliente;
	public String id_entidad;
	public String id_operacion;	
	public String id_usuario;
	public String nombres;
	public String deudaSol;
	public String deudaDol;
	public String diasmoras;
	public String direccion;
	public String telefono;		
	public String clave;
	public String urlsrv;
	public String urlloc;
	public Handler_sqlite(Context ctx)
	{
		super(ctx, "BDSigac", null,1);
	}
	@Override
	public void onCreate(SQLiteDatabase db)
	{
		// Creacion de tablas del SIGAC_MOV				
		db.execSQL("CREATE TABLE URL ("+_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, " +
				   "URLTXT TEXT)");
		Log.i("LocAndroid Response HTTP Threads","Creamdo tabla clientes");
		db.execSQL("CREATE TABLE usuario (" +
					  "id_usuario VARCHAR(13)  NOT NULL DEFAULT '' PRIMARY KEY, " +
					  "clave VARCHAR(20)  NOT NULL DEFAULT '')");
		
		Log.i("LocAndroid Response HTTP Threads","Creamdo tabla clientes");
		db.execSQL("CREATE TABLE clientes (" +
					  "ID_CLIENTE VARCHAR(13)  NOT NULL DEFAULT '' PRIMARY KEY, " +				      
					  "ID_ENTIDAD VARCHAR(20)  NOT NULL DEFAULT '', " +					  					  					  
					  "NOMBRE_1 VARCHAR(20)  DEFAULT NULL, " +
					  "NOMBRE_2 VARCHAR(20)  DEFAULT NULL, " +
					  "APE_PAT VARCHAR(20)  DEFAULT NULL, " +
					  "APE_MAT VARCHAR(20)  DEFAULT NULL, " +
					  "SEXO CHAR(1)  DEFAULT NULL, " +
					  "ID_ESTADO VARCHAR(20)  DEFAULT NULL)");
		
		Log.i("LocAndroid Response HTTP Threads","Creamdo tabla direcciones");
		db.execSQL("CREATE TABLE direccion (" +
				  "ID_CLIENTE VARCHAR(13) NOT NULL DEFAULT ''," +
				  "ID_DIRECCION DECIMAL(3,0) NOT NULL," +
				  "ID_ENTIDAD VARCHAR(20) NOT NULL DEFAULT ''," +				  				  				 
				  "DIRECCION_NUMBER VARCHAR(200) NOT NULL DEFAULT ''," +				  
				  "ZONA VARCHAR(60) NOT NULL DEFAULT ''," +
				  "CIUDAD VARCHAR(60) NOT NULL DEFAULT ''," +
				  "PROVINCE VARCHAR(60) DEFAULT NULL," +
				  "COUNTRY VARCHAR(30) DEFAULT NULL," +			
			      "DIRECCION_ESTADO VARCHAR(1) NOT NULL DEFAULT 'A')");
		
		Log.i("LocAndroid Response HTTP Threads","Creado tabla telefonos");		  
		db.execSQL("CREATE TABLE telefonos (" +
				   "ID_CLIENTE VARCHAR(13) NOT NULL DEFAULT ''," +
				   "ID_ENTIDAD VARCHAR(20) NOT NULL DEFAULT ''," +				  				  				 
				   "TELEFONO_TIPO VARCHAR(3) NOT NULL DEFAULT ''," +				  
				   "TELEFONO_NUMBER DECIMAL(11,0) NOT NULL," +
				   "DIRECCION_TIPO VARCHAR(15) NOT NULL DEFAULT 'RESIDENCE'," +
				   "LINEA_ESTADO VARCHAR(1) DEFAULT NULL DEFAULT 'A')");
		
		Log.i("LocAndroid Response HTTP Threads","Creado tabla cliente_cuenta");		  
		db.execSQL("CREATE TABLE cliente_cuenta (" +
				   "ID_CLIENTE VARCHAR(13) NOT NULL DEFAULT ''," +
				   "ID_ENTIDAD VARCHAR(20) NOT NULL DEFAULT ''," +				  				  				 
				   "ID_OPERACION VARCHAR(32) NOT NULL DEFAULT ''," +				  
				   "ID_CUENTA_ENTIDAD VARCHAR(20) NOT NULL DEFAULT ''," +
				   "ID_PRODUCTO VARCHAR(20) NOT NULL DEFAULT ''," +
				   "TIPO_RELACION VARCHAR(15) DEFAULT NULL DEFAULT '')");
		
		Log.i("LocAndroid Response HTTP Threads","Creado tabla cuenta");		  
		db.execSQL("CREATE TABLE cuenta (" +				
				   "ID_ENTIDAD VARCHAR(20) NOT NULL DEFAULT ''," +				  				  				 
				   "ID_OPERACION VARCHAR(32) NOT NULL DEFAULT ''," +				  
				   "CUST_BRANCH_ID VARCHAR(20) NOT NULL DEFAULT ''," +
				   "ID_PRODUCTO VARCHAR(20) NOT NULL DEFAULT ''," +
				   "BALANCE DECIMAL(15,2) NOT NULL DEFAULT '0.00'," +
				   "INTEREST_BALANCE DECIMAL(15,2) NOT NULL DEFAULT '0.00'," +
				   "DIAS_MORA DECIMAL(4,0) NOT NULL DEFAULT '0'," +
				   "DELINQUENCY DECIMAL(15,2) NOT NULL DEFAULT '0.00'," +
				   "CUENTA_ESTADO VARCHAR(10) NOT NULL DEFAULT 'A')");
		
		Log.i("LocAndroid Response HTTP Threads","Creado tabla tablas");		  
		db.execSQL("CREATE TABLE tabla_tablas (" +				
				   "ID_TABLA DECIMAL(10,0) NOT NULL DEFAULT '0'," +				  				  				 
				   "ID_ELEMENTO DECIMAL(10,0) NOT NULL DEFAULT '0'," +				  
				   "DESC_CORTA VARCHAR(50) NOT NULL DEFAULT ''," +
				   "DESC_LARGA VARCHAR(200) NOT NULL DEFAULT ''," +
				   "ESTADO VARCHAR(1) NOT NULL DEFAULT 'A')");		
		
		Log.i("LocAndroid Response HTTP Threads","Creado tabla Historial");		  
		db.execSQL("CREATE TABLE historial (" +				
				   "ID_CLIENTE VARCHAR(13) NOT NULL DEFAULT '0'," +				  				  				 
				   "HISTORIAL_DATE VARCHAR(50) NOT NULL DEFAULT '0'," +				  
				   "ID_USUARIO VARCHAR(20) NOT NULL DEFAULT ''," +
				   "ID_ENTIDAD VARCHAR(20) NOT NULL DEFAULT ''," +
				   "ACCION_ID VARCHAR(20) NOT NULL DEFAULT ''," +
				   "GROUP_ID VARCHAR(30) NOT NULL DEFAULT ''," +
				   "RESPUESTA_ID VARCHAR(25) NOT NULL DEFAULT ''," +
				   "CONTACTO_ID VARCHAR(20) NOT NULL DEFAULT ''," +
				   "TELEFONO_NUMBER VARCHAR(11) NOT NULL DEFAULT ''," +
				   "LONGITUD VARCHAR(30) NOT NULL DEFAULT ''," +
				   "LATITUD VARCHAR(30) NOT NULL DEFAULT ''," +
				   "UBICACION VARCHAR(50) NOT NULL DEFAULT ''," +
				   "BATERIA VARCHAR(3) NOT NULL DEFAULT '000')");		
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int version_ant, int version_new)
	{		
		db.execSQL("DROP TABLE IF EXISTS SIGAC_URL");
		db.execSQL("DROP TABLE IF EXISTS usuario");
		db.execSQL("DROP TABLE IF EXISTS clientes");
		db.execSQL("DROP TABLE IF EXISTS SIGAC_PROMESAS");
		db.execSQL("DROP TABLE IF EXISTS historial");
		db.execSQL("DROP TABLE IF EXISTS SIGAC_COMPROMISOS");
		db.execSQL("DROP TABLE IF EXISTS telefonos");
		db.execSQL("DROP TABLE IF EXISTS direccion");
		db.execSQL("DROP TABLE IF EXISTS tabla_tablas");
		db.execSQL("DROP TABLE IF EXISTS cliente_cuenta");
		db.execSQL("DROP TABLE IF EXISTS cuenta");
		db.execSQL("DROP TABLE IF EXISTS SIGAC_TIPO_CAMBIO");
		onCreate(db);		
	}
	
	public void insertarRegUrl(String urltext)
	{
		ContentValues valores= new ContentValues();
		valores.put("URLTXT",urltext);		
		this.getWritableDatabase().delete("URL", null, null);
		this.getWritableDatabase().insert("URL", null, valores);
	}	
	public void insertarRegUsuario(String id_usuario, String clave)
	{
		ContentValues valores= new ContentValues();
		valores.put("id_usuario",id_usuario);
		valores.put("clave",clave);
		this.getWritableDatabase().delete("usuario", null, null);
		this.getWritableDatabase().insert("usuario", null, valores);		
	}
	public void leerUsuario()
	{
		String[] campos = new String[] {"id_usuario", "clave",};				
		String[] list=null;		
		Cursor c=this.getReadableDatabase().query("usuario", campos, null, null, null, null, null);		
		if (c.moveToFirst()){			
			do
		    {
				 this.id_usuario = c.getString(0); 
				 this.clave= c.getString(1);				  						 
		    }while(c.moveToNext());			
		}else{
			Log.i("LocAndroid Response HTTP Threads","valor de la tabla no existe");
		}
		c.close();
	}
	public String leerURL()
	{
		Log.i("LocAndroid Response HTTP Threads","oteniendo url");
		String result="";
		String columnas[]= {_ID,"URLTXT"};
		Cursor c=this.getReadableDatabase().query("URL", columnas, null, null, null, null, null);
		if (c.moveToFirst()){
			int id,url;
			id = c.getColumnIndex(_ID);
			url = c.getColumnIndex("URLTXT");
			this.urlsrv = c.getString(1);
			Log.i("LocAndroid Response HTTP Threads","url serv: " + this.urlsrv);			
			c.moveToLast();
			result = c.getString(id)+"-"+c.getString(url)+"\n";
		}
		c.close();
		return result;
	}
	public boolean cargarlista(String id_usuario){
		boolean condicion=false;
		/*-Eliminando tabla---*/
		Log.i("LocAndroid Response HTTP Threads","Borrando tabla clientes, telefonos, tabla_tablas,cliente_cuenta, cuenta, direccion");
		this.getWritableDatabase().delete("clientes", null, null);
		this.getWritableDatabase().delete("telefonos", null, null);
		this.getWritableDatabase().delete("tabla_tablas", null, null);
		this.getWritableDatabase().delete("cliente_cuenta", null, null);
		this.getWritableDatabase().delete("cuenta", null, null);
		this.getWritableDatabase().delete("direccion", null, null);		
		/*--------------------*/
		condicion = this.insertarRegCliente(id_usuario);
		Log.i("LocAndroid Response HTTP Threads","Inserta tabla_tablas: "+insertarRegTablaTablas());
		return condicion;
	}
	public boolean insertarRegCliente(String id_usuario) 
	{		
		Log.i("LocAndroid Response HTTP Threads","Consulta cliente id_usuario="+id_usuario);
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		boolean condicion=false;		
		try{			
			leerURL();
			String pUrl=  this.urlsrv;
			String dta ="";
			datos=BA.httpGetData(pUrl+"/lista_clientes.php?id_usuario="+id_usuario);			
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray("clientes");															
				for (int i = 0; i < ja1.length(); i++) {
					JSONObject ja = ja1.getJSONObject(i);				 
					id_cliente =ja.optString("ID_CLIENTE");
					id_entidad = ja.optString("ID_ENTIDAD");				    				    
				    valores.put("ID_CLIENTE",ja.optString("ID_CLIENTE").trim());
				    valores.put("ID_ENTIDAD",ja.optString("ID_ENTIDAD").trim());
				    valores.put("NOMBRE_1",ja.optString("NOMBRE_1").trim());
				    valores.put("NOMBRE_2",ja.optString("NOMBRE_2").trim());
				    valores.put("APE_PAT",ja.optString("APE_PAT").trim());
				    valores.put("APE_MAT",ja.optString("APE_MAT").trim());
				    valores.put("SEXO",ja.optString("SEXO").trim());
				    valores.put("ID_ESTADO",ja.optString("ID_ESTADO").trim());
				    this.getWritableDatabase().insert("clientes", null, valores);
				    Log.i("LocAndroid Response HTTP Threads","Insertar clientes: "+valores);
				    Log.i("LocAndroid Response HTTP Threads","Insertar Direcciones: "+this.insertarRegDirecciones(this.id_cliente, this.id_entidad)+"");
				    Log.i("LocAndroid Response HTTP Threads","Insertar Telefonos: "+this.insertarRegTelefono(this.id_cliente, this.id_entidad)+"");
				    Log.i("LocAndroid Response HTTP Threads","Insertar Cliente Cuenta: "+this.insertarRegClienteCuenta(this.id_cliente, this.id_entidad)+"");				    				   
				    condicion=true;
				   }				
	         }
		}catch(Exception e){        	
			Log.i("LocAndroid Response HTTP Threads","Error al inserta clientes "+e.getMessage());  
			condicion=false;
        }												
		return condicion;
	}
	public boolean insertarRegDirecciones(String id_cliente, String id_entidad) 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		String tabla="direccion";
		boolean condicion=false;  		
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			Log.i("LocAndroid Response HTTP Threads","URL: "+pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);  
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int i = 0; i < ja1.length(); i++) {
					JSONObject ja = ja1.getJSONObject(i);	
					  Iterator iter = ja.keys();
					  while(iter.hasNext()){
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				   }					
	         }
		}catch(Exception e){        
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }						
		return condicion;								
	}
	public boolean insertarRegTelefono(String id_cliente, String id_entidad) 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		String tabla="telefonos"; 
		boolean condicion=false;		
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			Log.i("LocAndroid Response HTTP Threads","URL: "+pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int i = 0; i < ja1.length(); i++) {
					JSONObject ja = ja1.getJSONObject(i);	
					  Iterator iter = ja.keys();
					  while(iter.hasNext()){
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				   }					
	         }
		}catch(Exception e){      
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }					
		return condicion;								
	}
	public boolean insertarRegTablaTablas() 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		String tabla="tabla_tablas"; 
		boolean condicion=false;		
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			Log.i("LocAndroid Response HTTP Threads","URL: "+pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int i = 0; i < ja1.length(); i++) {
					JSONObject ja = ja1.getJSONObject(i);	
					  Iterator iter = ja.keys();
					  while(iter.hasNext()){
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				   }					
	         }
		}catch(Exception e){      
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }					
		return condicion;								
	}
	public boolean insertarRegClienteCuenta(String id_cliente, String id_entidad) 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		boolean condicion=false; 
		String tabla="cliente_cuenta"; 		
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			Log.i("LocAndroid Response HTTP Threads","URL: "+pUrl+"/"+tabla+".php?tcon=MC&id_cliente="+ id_cliente +"&id_entidad=" + id_entidad);
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int x = 0; x < ja1.length(); x++) {										
					JSONObject ja = ja1.getJSONObject(x);	
					this.id_operacion=ja.optString("ID_OPERACION");
					Log.i("LocAndroid Response HTTP Threads","Operacion: "+this.id_operacion);
					  Iterator iter = ja.keys();
					  while(iter.hasNext()){
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				    Log.i("LocAndroid Response HTTP Threads","Insertar Cuenta: "+this.insertarRegCuenta(this.id_operacion, this.id_entidad)+"");
				   }					
	         }
		}catch(Exception e){      
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }						
		return condicion;
	}
	public boolean insertarRegCuenta(String id_operacion, String id_entidad) 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		boolean condicion=false;
		String tabla="cuenta"; 	
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/"+tabla+".php?tcon=MC&id_operacion="+ id_operacion +"&id_entidad=" + id_entidad);
			Log.i("LocAndroid Response HTTP Threads","URL: "+pUrl+"/"+tabla+".php?tcon=MC&id_operacion="+ id_operacion +"&id_entidad=" + id_entidad);
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int i = 0; i < ja1.length(); i++) {					 
					JSONObject ja = ja1.getJSONObject(i);	
					  Iterator iter = ja.keys();					  
					  while(iter.hasNext()){						    
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				   }					
	         }
		}catch(Exception e){       
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }							
		return condicion;	
	}
	public boolean insertarRegHistorial(String id_operacion, String id_entidad) 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		boolean condicion=false;
		String tabla="cuenta"; 	
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/"+tabla+".php?tcon=MC&id_operacion="+ id_operacion +"&id_entidad=" + id_entidad);
			Log.i("LocAndroid Response HTTP Threads","URL: "+"http://"+pUrl+"/"+tabla+".php?tcon=MC&id_operacion="+ id_operacion +"&id_entidad=" + id_entidad);
			if (datos.length()>10){
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int i = 0; i < ja1.length(); i++) {					 
					JSONObject ja = ja1.getJSONObject(i);	
					  Iterator iter = ja.keys();					  
					  while(iter.hasNext()){						    
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				   }					
	         }
		}catch(Exception e){       
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }							
		return condicion;	
	}
	public ArrayList<HashMap<String, String>> leerRegCliente()
	{				
		ArrayList<HashMap<String, String>> results = new ArrayList<HashMap<String, String>>();				
		Cursor c=this.getReadableDatabase().query("clientes", null, null, null, null, null, null);					
		if (c.moveToFirst()){						
			do
		    {		    
		    //example: String a=c.getString(0);
			HashMap<String, String> map = new HashMap<String, String>();
			String dni = c.getString(0);
			String nombre = c.getString(2)+" "+c.getString(3)+" "+c.getString(4);			
			map.put("itemDNI", dni);     
	        map.put("itemNombre", nombre);
			results.add(map);
			Log.i("LocAndroid Response HTTP Threads","Clinte:"+nombre);
		    }while(c.moveToNext());			
		}							
		c.close();
		return results;
	}
	public ArrayList<HashMap<String, String>> leerRegTelefonos(String id_cliente)
	{				
		ArrayList<HashMap<String, String>> results = new ArrayList<HashMap<String, String>>();
		String[] campos = new String[] {"TELEFONO_TIPO", "TELEFONO_NUMBER", "DIRECCION_TIPO"};						
		Cursor c=this.getReadableDatabase().query("telefonos", campos, "ID_CLIENTE="+id_cliente, null, null, null, null);					
		if (c.moveToFirst()){						
			do
		    {		    
		    //example: String a=c.getString(0);
			HashMap<String, String> map = new HashMap<String, String>();
			String tip = c.getString(0)+"-"+c.getString(2);
			String telf = c.getString(1);			
			map.put("itemDNI", tip);     
	        map.put("itemNombre", telf);
			results.add(map);
			Log.i("LocAndroid Response HTTP Threads","Cliente:"+telf);
		    }while(c.moveToNext());			
		}							
		c.close();
		return results;
	}
	public ArrayList<HashMap<String, String>> leerRegDireccion(String id_cliente)
	{				
		ArrayList<HashMap<String, String>> results = new ArrayList<HashMap<String, String>>();
		String[] campos = new String[] {"DIRECCION_NUMBER","ZONA","CIUDAD","PROVINCE","COUNTRY"};						
		Cursor c=this.getReadableDatabase().query("direccion", campos, "ID_CLIENTE="+id_cliente, null, null, null, null);					
		if (c.moveToFirst()){						
			do
		    {		    
		    //example: String a=c.getString(0);
			HashMap<String, String> map = new HashMap<String, String>();
			String tip = "S/T";
			String dir = c.getString(0)+"-"+c.getString(1)+"-"+c.getString(2)+"-"+c.getString(3)+"-"+c.getString(4);			
			map.put("itemDNI", tip);     
	        map.put("itemNombre", dir);
			results.add(map);
			Log.i("LocAndroid Response HTTP Threads","Cliente:"+dir);
		    }while(c.moveToNext());			
		}							
		c.close();
		return results;
	}
	public ArrayList<HashMap<String, String>> leerRegOperacion(String id_cliente)
	{				
		ArrayList<HashMap<String, String>> results = new ArrayList<HashMap<String, String>>();
		Cursor c1=null;
		String[] campos = new String[] {"ID_OPERACION"};						
		Cursor c=this.getReadableDatabase().query("cliente_cuenta", campos, "ID_CLIENTE="+id_cliente, null, null, null, null);					
		if (c.moveToFirst()){											    
				Log.i("LocAndroid Response HTTP Threads","Cliente:"+id_cliente+ " Operacion: "+c.getString(0).toString());
				campos = new String[] {"ID_OPERACION, CUST_BRANCH_ID, ID_PRODUCTO, BALANCE, INTEREST_BALANCE, DIAS_MORA, DELINQUENCY"};						
				c1=this.getReadableDatabase().query("cuenta", campos, "ID_OPERACION="+c.getString(0).toString(), null, null, null, null);
				if (c1.moveToFirst()){						
					do
				    {	
						//example: String a=c.getString(0);
						Log.i("LocAndroid Response HTTP Threads","Cliente:"+c1.getString(0));
						HashMap<String, String> map = new HashMap<String, String>();
						String operacion = c1.getString(0);
						String descripcion = "Ent. Prod.: " + c1.getString(1) + " Producto: " + c1.getString(2) + " Capital: " + c1.getString(3) + " Interes: " + c1.getString(4) + " Dias Mora: " + c1.getString(5) + " Cuota: " + c1.getString(6);															
						map.put("itemCod", operacion);     
						map.put("itemDesc", descripcion);																		
						results.add(map);
						Log.i("LocAndroid Response HTTP Threads","Cliente:"+operacion);
				    }while(c1.moveToNext());					
				}		    			
		}					
		c.close();
		c1.close();
		return results;
	}
	public void leerRegDeuda(String id_cliente)
	{		
		Cursor c = null;
		Cursor c1 = null;
		Cursor c2 = null;
		try{
			this.id_cliente = id_cliente;
			Log.i("LocAndroid Response HTTP Threads","Iniciando extraccion"+id_cliente);
			String[] campos = new String[] {"ID_CLIENTE", "APE_PAT", "APE_MAT", "NOMBRE_1", "NOMBRE_2"};				
			c=this.getReadableDatabase().query("clientes", campos, "ID_CLIENTE="+id_cliente, null, null, null, null);
			/*--- Unica al cliente --*/
			if (c.moveToFirst()){	
				nombres = c.getString(1)+" "+c.getString(2)+" "+c.getString(3)+" "+c.getString(4);				
				Log.i("LocAndroid Response HTTP Threads","Cliente econtrado: "+nombres);
				/*---- Ubica telefono */
				String[] campostelf = new String[] {"TELEFONO_TIPO","TELEFONO_NUMBER","DIRECCION_TIPO"};
				Cursor ct=this.getReadableDatabase().query("telefonos", campostelf, "ID_CLIENTE="+id_cliente, null, null, null, null);			
				if (ct.moveToFirst()){				
					this.telefono=ct.getString(1);
					Log.i("LocAndroid Response HTTP Threads","Telefono: "+telefono);
				}
				ct.close();
				/*---- Ubica Direccion */
				String[] camposdir = new String[] {"DIRECCION_NUMBER","ZONA","CIUDAD","PROVINCE","COUNTRY"};
				Cursor cd=this.getReadableDatabase().query("direccion", camposdir, "ID_CLIENTE="+id_cliente, null, null, null, null);			
				if (cd.moveToFirst()){
					this.direccion = cd.getString(0)+"-"+cd.getString(1)+"-"+cd.getString(2)+"-"+cd.getString(3)+"-"+cd.getString(4);
					Log.i("LocAndroid Response HTTP Threads","Direccion: "+direccion);
				}
				cd.close();
				/*--- ****** --*/			
				String[] camposcta = new String[] {"ID_CLIENTE", "ID_ENTIDAD", "ID_OPERACION", "ID_CUENTA_ENTIDAD", "ID_PRODUCTO","TIPO_RELACION"};
				c1=this.getReadableDatabase().query("cliente_cuenta", camposcta, "ID_CLIENTE='"+id_cliente+"'", null, null, null, null);			
				if (c1.moveToFirst()){
					do {
					String id_operacion= c1.getString(2);				
					Log.i("LocAndroid Response HTTP Threads","Operacion: "+id_operacion);
					String[] camposdeu = new String[] {"BALANCE", "INTEREST_BALANCE", "DELINQUENCY", "DIAS_MORA"};
					c2=this.getReadableDatabase().query("cuenta", camposdeu, "ID_OPERACION="+id_operacion, null, null, null, null);
					double deusol=0;
					double deudol=0;
					double diamor=0;
					if (c2.moveToFirst()){
						Log.i("LocAndroid Response HTTP Threads","Encontro Operacion: "+id_operacion);
						do{
							deusol = deusol + c2.getDouble(0);
							this.deudaSol=Double.toString(deusol);
							if (c2.getDouble(3)>diamor){
								diamor=c2.getDouble(3);
								diasmoras = Double.toString(diamor);
							}
						}while (c2.moveToNext());						
					Log.i("LocAndroid Response HTTP Threads","Deuda: "+deusol+" Dias morosida: "+diamor);					
					}
					c2.close();
				} while (c1.moveToNext());
				}				
				c1.close();
			}				
			c.close();
		}catch(Exception e){
			c.close();
			c1.close();
			c2.close();
			Log.i("LocAndroid Response HTTP Threads","Error: "+e.getMessage());
		}
		//return results;
	}
	public List<String> lista_tabla_tablas(String id_tabla){
		int cont = -1;
		int pos= 0;	
		List<String> labels = new ArrayList<String>();
		String[] campos = new String[] {"ID_TABLA", "ID_ELEMENTO","DESC_LARGA"};
		String[] args = new String[] {id_tabla};		
		String[] list=null;		
		Cursor c=this.getReadableDatabase().query("tabla_tablas", campos, "ID_TABLA="+id_tabla, null, null, null, "ID_ELEMENTO ASC");		
		if (c.moveToFirst()){
			list = new String[pos];
			do
		    {
				 labels.add(c.getString(2));
		    }while(c.moveToNext());			
		}else{
			Log.i("LocAndroid Response HTTP Threads","valor de la tabla no existe");
		}
		c.close();
		return labels;
	}
	public static String[] convertString(ArrayList<String> String)
	{
	    String[] ret = new String[String.size()];
	    Iterator<String> iterator = String.iterator();
	    for (int i = 0; i < ret.length; i++)
	    {
	        ret[i] = iterator.next().toString();
	        Log.i("LocAndroid Response HTTP Threads","Clinte:"+ret[i]);
	    }
	    return ret;
	}
	public void abrir()
	{
		this.getWritableDatabase();
	}
	public void cerrar()
	{
		this.close();
	}
	public boolean mntRegTelefono(String id_cliente, String id_entidad, String telefono, String tiptelf) 
	{		
		String datos;
		JSONArray ja1=null;
		ContentValues valores= new ContentValues();		
		BaseActivity BA = new BaseActivity();
		String tabla="telefonos"; 
		boolean condicion=false;		
		try{			
			this.leerURL(); 
			String pUrl= this.urlsrv;			
			datos=BA.httpGetData(pUrl+"/mntTelefono.php?id_cliente="+ id_cliente +"&id_entidad=" + id_entidad+"&telefono=" + telefono+"&tipo=" + tiptelf);
			Log.i("LocAndroid Response HTTP Threads",pUrl+"/mntTelefono.php?id_cliente="+ id_cliente +"&id_entidad=" + id_entidad+"&telefono=" + telefono+"&tipo=" + tiptelf);
			if (datos.length()>10){     
				JSONObject jsonResponse = new JSONObject(datos);
				ja1 = jsonResponse.optJSONArray(tabla);
				//Log.i("LocAndroid Response HTTP Threads",dta.toString());												
				for (int i = 0; i < ja1.length(); i++) {
					JSONObject ja = ja1.getJSONObject(i);	
					  Iterator iter = ja.keys();
					  while(iter.hasNext()){
					        String key = (String)iter.next();
					        String value = ja.optString(key).trim();
					        valores.put(key,value);					        
					  }									   
				    this.getWritableDatabase().insert(tabla, null, valores);
				    condicion=true;
				    Log.i("LocAndroid Response HTTP Threads","Insertar "+tabla+": "+valores);
				   }					
	         }
		}catch(Exception e){      
			condicion=false;
			Log.i("LocAndroid Response HTTP Threads","Error al inserta "+tabla+": "+e.getMessage());     	
        }					
		return condicion;								
	}
}
