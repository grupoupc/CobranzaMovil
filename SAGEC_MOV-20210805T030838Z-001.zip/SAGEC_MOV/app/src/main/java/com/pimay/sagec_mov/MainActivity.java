package com.pimay.sagec_mov;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.sigac.tools.*;

public class MainActivity extends BaseActivity   {
	ProgressThread progThread;
    ProgressDialog progDialog;
    private RadioGroup rg1;
    private RadioGroup rg2;
    private RadioButton rsb1;
    private RadioButton rsb2;
    private Button btnDisplay;
    Button button1, button2;
	int typeBar;                        // Determines type progress bar: 0 = spinner, 1 = horizontal
	String pURL;
	String data;
	int delay = 40;                   // Milliseconds of delay in the update loop
	int maxBarValue = 200;      // Maximum value of horizontal progress bar
	Handler_sqlite helper=null;
	//private BaseActivity BA;
	//http://www.infosistema.comuf.com/sigac.php	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*****************/                           
        pURL=getIP();        
        Log.i("LocAndroid Response HTTP Threads","URL: "+pURL+"");        			                                      
        Button b1=(Button)findViewById(R.id.btnLogin);
        final EditText u1=(EditText)findViewById(R.id.editUser);
        final EditText u2=(EditText)findViewById(R.id.editPassword);
        helper= new Handler_sqlite(this);
        b1.setOnClickListener(new View.OnClickListener() {
			@SuppressLint("ShowToast") @Override
			public void onClick(View v) {										          				 
				  typeBar = 0;				  			
                  showDialog(typeBar);
				  JSONArray ja=null;				  
				  String xlongitud="";
		          String xlatitud="";
		          String xcellid="";		          
			        try{						        	
			            pURL=getIP();
			            String telefono = getPhoneNumber();
			        	Log.i("LocAndroid Response HTTP Threads","Celular: "+telefono);			        	
			        	if (checkGPS()==true){
			        		Log.i("LocAndroid Response HTTP Threads","Estado GPS: Activo");
			        		if (getCurrentLocation()==true){
			        			xlongitud=longitud;
					        	xlatitud =latitud;
					        	Log.i("LocAndroid Response HTTP Threads","Estado GPS longitud: "+xlongitud);
					        	Log.i("LocAndroid Response HTTP Threads","Estado GPS latitud: "+xlatitud);
			        		}
			        	}
			        	else{
			        		xcellid = getCellId(); 
			        		Log.i("LocAndroid Response HTTP Threads","Estado GPS: Inactivo");
			        	}
			        	data =httpGetData(pURL+"/lista_usuario.php?tcon=MC&id_usuario="+u1.getText()+"&clave="+u2.getText()+"&celular="+telefono+"&latitud="+xlatitud+"&longitud="+xlongitud+"&cellid="+xcellid+"&imei="+getIMEI().toString().trim()+"&bateria="+getBatterLevel().toString().trim()+"&id_entidad=VIDAL");			        	
			            if (data.length()>1){
			            	ja=new JSONArray(data);			            	
			                pURL=getIP();						                
			                helper.abrir();
			                helper.leerUsuario();			                
			                if (helper.id_usuario==null){
			                	helper.insertarRegUsuario(u1.getText().toString().trim(), u2.getText().toString().trim());
			                	if (helper.cargarlista(u1.getText().toString())){
			                		helper.cerrar();
				                	Log.i("LocAndroid Response HTTP Threads",helper.id_cliente +":"+helper.id_entidad);			                	
	            					Intent siguiente=new Intent(MainActivity.this,ListaClientes.class);
					            	siguiente.putExtra("id_usuario", ja.getString(0));
					            	startActivity(siguiente);				                			                	
				                }
			                }else{
			                	helper.cerrar();
			                	Log.i("LocAndroid Response HTTP Threads",helper.id_cliente +":"+helper.id_entidad);			                	
            					Intent siguiente=new Intent(MainActivity.this,ListaClientes.class);
				            	siguiente.putExtra("id_usuario",u1.getText().toString().trim());
				            	startActivity(siguiente);				                			                					                
			                }			                			                			            				           			            				            	
			            }
			            else{
			            	Toast toast = Toast.makeText(getApplicationContext(), "Error: usuario o clave son incorrectas...", Toast.LENGTH_SHORT);
			            	toast.show(); 
			            	helper.cerrar();
			            }
			            	
			        }catch(Exception e){
			        	Toast toast = Toast.makeText(getApplicationContext(), "Error: usuario o clave son incorrectas..."+e.getMessage(), Toast.LENGTH_SHORT);
		            	toast.show();       
		            	helper.cerrar();
			        }			  
			}
		});
      
        
        
        /*Handler_sqlite helper= new Handler_sqlite(this);        
        TextView text=(TextView)findViewById(R.id.text);                
        helper.abrir();
        helper.insertarRegUrl("http://localhost/WSSIGAC/TramaMovil.asmx");
        text.setText(helper.leerURL());
        helper.cerrar();*/        
    }
 // Method to create a progress bar dialog of either spinner or horizontal type
    @Override
    protected Dialog onCreateDialog(int id) {
        switch(id) {
        case 0:                      // Spinner
            progDialog = new ProgressDialog(this);
            progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progDialog.setMessage("Loading...");
            progThread = new ProgressThread(handler);
            progThread.start();
            return progDialog;
        case 1:                      // Horizontal
        	progDialog = new ProgressDialog(this);
            progDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progDialog.setMax(maxBarValue);
            progDialog.setMessage("Dollars in checking account:");
            progThread = new ProgressThread(handler);
            progThread.start();
            return progDialog;
        default:
            return null;
        }
    }

    // Handler on the main (UI) thread that will receive messages from the 
    // second thread and update the progress.
    
    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
        	// Get the current value of the variable total from the message data
        	// and update the progress bar.
            int total = msg.getData().getInt("total");
            progDialog.setProgress(total);
            if (total <= 0){
                dismissDialog(typeBar);
                progThread.setState(ProgressThread.DONE);
            }
        }
    };

    // Inner class that performs progress calculations on a second thread.  Implement
    // the thread by subclassing Thread and overriding its run() method.  Also provide
    // a setState(state) method to stop the thread gracefully.
    
    private class ProgressThread extends Thread {	
    	
    	// Class constants defining state of the thread
    	final static int DONE = 0;
        final static int RUNNING = 1;
        
        Handler mHandler;
        int mState;
        int total;
       
        // Constructor with an argument that specifies Handler on main thread
        // to which messages will be sent by this thread.
        
        ProgressThread(Handler h) {
            mHandler = h;
        }
               
        @Override
        public void run() {
            mState = RUNNING;   
            total = maxBarValue;
            while (mState == RUNNING) {
            	// The method Thread.sleep throws an InterruptedException if Thread.interrupt() 
            	// were to be issued while thread is sleeping; the exception must be caught.
                try {
                	// Control speed of update (but precision of delay not guaranteed)
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("ERROR", "Thread was Interrupted");
                }
                
                // Send message (with current value of  total as data) to Handler on UI thread
                // so that it can update the progress bar.
                
                Message msg = mHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putInt("total", total);
                msg.setData(b);
                mHandler.sendMessage(msg);
                
                total--;      // Count down
            }
        }
        
        // Set current state of thread (use state=ProgressThread.DONE to stop thread)
        public void setState(int state) {
            mState = state;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.menu_url, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
    	helper= new Handler_sqlite(this);
    	try{
	        switch (item.getItemId()) {
	            case R.id.OpcSincro:
	                //newGame();
	            	helper.abrir();
	            	final EditText u1=(EditText)findViewById(R.id.editUser);
	            	Log.i("LocAndroid Reponse HTTP ERROR 2","En proceso de carga de valores...");
	            	if (helper.cargarlista(u1.getText().toString())){
	            		Toast toast = Toast.makeText(getApplicationContext(), "Carga de valores para gestion realizada con exito", Toast.LENGTH_SHORT);
		            	toast.show();	
	            	}else{
	            		Toast toast = Toast.makeText(getApplicationContext(), "El usuario ingresado no existe...", Toast.LENGTH_SHORT);
		            	toast.show();
	            	}     
	            	helper.cerrar();
	                return true;   
	            case R.id.OpcConfig:
	            	helper.cerrar();
	            	Intent gestion=new Intent(MainActivity.this,ConfiguracionActivity.class);            	
	            	startActivity(gestion);			
	            default:
	                return super.onOptionsItemSelected(item);
	        }    	
    	} catch (Exception e) {
    		Log.i("LocAndroid Reponse HTTP ERROR 2",e.getMessage());
    		helper.cerrar();
    		return false;
    	}    
    }
}
