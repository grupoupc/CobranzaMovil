package com.pimay.sagec_mov;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;
import com.example.sigac_mov.R;
import com.sigac.tools.BaseActivity;
import com.sigac.tools.Handler_sqlite;

public class ConfiguracionActivity extends BaseActivity{
	
	private EditText editURL;	
	Handler_sqlite helper=null;	
	
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);	
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.config);		
		editURL = (EditText)findViewById(R.id.editURL);						
		editURL.setText(this.getIP());				
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.menu_config, menu);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		helper= new Handler_sqlite(this);
		helper.abrir();
		switch (item.getItemId()) {
        case R.id.OpcConfig:
        	if(editURL.getText().toString().trim().equals("")){
        		Toast.makeText(getApplicationContext(), "Ingrese el URL",Toast.LENGTH_SHORT).show();
        	}else{
        		if(helper.leerURL() == null){        			            		
            		helper.insertarRegUrl(editURL.getText().toString().trim());
            		helper.cerrar();
        		}else{
        			helper.insertarRegUrl(editURL.getText().toString().trim());
        			helper.cerrar();
        		}
        		startActivity(new Intent(ConfiguracionActivity.this,MainActivity.class));
        		finish();
        	}
            return true;        	
        default:
        	helper.cerrar();
            return super.onOptionsItemSelected(item);            
		}		
	}	
}
