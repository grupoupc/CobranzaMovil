package com.pimay.sagec_mov;

import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONArray;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.sigac.tools.BaseActivity;
import com.sigac.tools.Handler_sqlite;

public class ExampleService extends Service {
	 private Timer mTimer = null;	
	 @Override
	 public IBinder onBind(Intent arg0) {
	  return null;
	 }
	 
	 @Override
	 public void onCreate(){
	  super.onCreate();	  
	  this.mTimer = new Timer();
	  this.mTimer.scheduleAtFixedRate(
	    new TimerTask(){	    	
	     @Override
	     public void run() {
	    	 Toast toast = Toast.makeText(getApplicationContext(), "Error: usuario o clave son incorrectas...", Toast.LENGTH_SHORT);
         	toast.show();
	      //ejecutarTarea();
	     }      
	    }
	    , 0, 1000 * 60);
	 }
	 
	 private void ejecutarTarea(){
	  Thread t = new Thread(new Runnable() {
	   public void run() {		   					 
		   	 BaseActivity BA=new BaseActivity();
		   	 Handler_sqlite HaSql=new Handler_sqlite(ExampleService.this); 
	         //**------ Ejecutando servicios **/
	          String data="";
	          String pURL="";
	          JSONArray ja=null;
			  String xlongitud="";
	          String xlatitud="";
	          String xcellid="";		          
		        try{						        	
		            pURL=BA.getIP();
		            String telefono =BA.getPhoneNumber();
		        	Log.i("LocAndroid Response HTTP Threads","Celular: "+telefono);			        	
		        	if (BA.checkGPS()==true){
		        		Log.i("LocAndroid Response HTTP Threads","Estado GPS: Activo");
		        		if (BA.getCurrentLocation()==true){
		        			xlongitud=BA.longitud;
				        	xlatitud =BA.latitud;
				        	Log.i("LocAndroid Response HTTP Threads","Estado GPS longitud: "+xlongitud);
				        	Log.i("LocAndroid Response HTTP Threads","Estado GPS latitud: "+xlatitud);
		        		}
		        	}
		        	else{
		        		xcellid = BA.getCellId(); 
		        		Log.i("LocAndroid Response HTTP Threads","Estado GPS: Inactivo");
		        	}
		        	data =BA.httpGetData("http://"+pURL+"/lista_usuario.php?tcon=MC&id_usuario="+HaSql.id_usuario.toString()+"&clave="+HaSql.clave+"&celular="+telefono+"&latitud="+xlatitud+"&longitud="+xlongitud+"&cellid="+xcellid+"&imei="+BA.getIMEI().toString().trim()+"&bateria="+BA.getBatterLevel().toString().trim()+"&id_entidad=VIDAL");
		        	Log.i("LocAndroid Response HTTP Threads","http://"+pURL+"/lista_usuario.php?tcon=MC&id_usuario="+HaSql.id_usuario.toString()+"&clave="+HaSql.clave+"&celular="+telefono+"&latitud="+xlatitud+"&longitud="+xlongitud+"&cellid="+xcellid+"&imei="+BA.getIMEI().toString().trim()+"&bateria="+BA.getBatterLevel().toString().trim()+"&id_entidad=VIDAL");
		            if (data.length()>1){
		            	ja=new JSONArray(data);
		            	if (ja.length()<1){
		            		Toast toast = Toast.makeText(getApplicationContext(), "Error: usuario o clave son incorrectas...", Toast.LENGTH_SHORT);
			            	toast.show();
		            	}		                		                        		                			                			            				           			            				            	
		            }
		            else{
		            	Toast toast = Toast.makeText(getApplicationContext(), "Error: usuario o clave son incorrectas...", Toast.LENGTH_SHORT);
		            	toast.show(); 
		            }
		            HaSql.cerrar();	
		        }catch(Exception e){
		        	Toast toast = Toast.makeText(getApplicationContext(), "Error: usuario o clave son incorrectas..."+e.getMessage(), Toast.LENGTH_SHORT);
	            	toast.show();       
	            	HaSql.cerrar();
		        }			  	         	         	        
	   }
	  });  
	  t.start();
	 }

}
