package com.pimay.sagec_mov.generales;

import java.io.IOException;

import org.kobjects.base64.Base64;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapPrimitive;
import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.sigac.tools.*;
public class CargaDatosWS {
	BaseActivity BA = new BaseActivity();
	public String Carga(){
		JSONObject json = null; 
		String response="";
        HttpClient myClient = new DefaultHttpClient();
        Log.i("LocAndroid Response HTTP Threads ", "Abriendo URL: "+BA.getIP());
        HttpPost myConnection = new HttpPost(BA.getIP());
        try {
        	ResponseHandler<String> responseHandler=new BasicResponseHandler();
        	response = myClient.execute(myConnection, responseHandler);
        	Log.i("LocAndroid Response HTTP Threads ", "Abriendo URL: "+response);
            //str = EntityUtils.toString(response.getEntity(), "UTF-8");
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try{
        	JSONObject jsonResponse = new JSONObject(response);
        	JSONArray ja = jsonResponse.optJSONArray("clientes");															
			JSONObject ja1 = ja.getJSONObject(0);	
        	return ja1.optString("ID_CLIENTE") + "," + ja1.optString("ID_ENTIDAD");
        } catch ( JSONException e) {
        	return e.getMessage(); 
        }
	}
	
}