package com.pimay.sagec_mov;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.pimay.sagec_mov.tools.*;

public class Promesa extends BaseActivity   {
	ProgressThread progThread;
    ProgressDialog progDialog;
    Button button1, button2;
    public String id_cliente;
	int typeBar;                        // Determines type progress bar: 0 = spinner, 1 = horizontal
	String pURL;
	String data;
	int delay = 40;                   // Milliseconds of delay in the update loop
	int maxBarValue = 200;      // Maximum value of horizontal progress bar
	Handler_sqlite helper=null;
	//private BaseActivity BA;
	//http://www.infosistema.comuf.com/sigac.php	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deuda);                              
        Button b1=(Button)findViewById(R.id.btnLogin);        
        helper= new Handler_sqlite(this);
        helper.abrir();        
        Bundle bundle = this.getIntent().getExtras();
        id_cliente=bundle.getString("id_cliente").toString();
        helper.leerRegDeuda(id_cliente);
        //helper.direccion;        
        final TextView pdoc=(TextView)findViewById(R.id.lblDoc);
        final TextView pnombres=(TextView)findViewById(R.id.lblNombre);
        final TextView pimporteS=(TextView)findViewById(R.id.lblimporte1);
        final TextView pimporteD=(TextView)findViewById(R.id.lblimporte2);        
        pdoc.setText(helper.id_cliente);        
        pnombres.setText(helper.nombres);
        pimporteS.setText(helper.deudaSol);
        pimporteD.setText(helper.deudaDol);                        
        helper.cerrar();             
        /*Handler_sqlite helper= new Handler_sqlite(this);        
        TextView text=(TextView)findViewById(R.id.text);                
        helper.abrir();
        helper.insertarRegUrl("http://localhost/WSSIGAC/TramaMovil.asmx");
        text.setText(helper.leerURL());
        helper.cerrar();*/        
    }
 // Method to create a progress bar dialog of either spinner or horizontal type
    @Override
    protected Dialog onCreateDialog(int id) {
        switch(id) {
        case 0:                      // Spinner
            progDialog = new ProgressDialog(this);
            progDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progDialog.setMessage("Loading...");
            progThread = new ProgressThread(handler);
            progThread.start();
            return progDialog;
        case 1:                      // Horizontal
        	progDialog = new ProgressDialog(this);
            progDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progDialog.setMax(maxBarValue);
            progDialog.setMessage("Dollars in checking account:");
            progThread = new ProgressThread(handler);
            progThread.start();
            return progDialog;
        default:
            return null;
        }
    }

    // Handler on the main (UI) thread that will receive messages from the 
    // second thread and update the progress.
    
    final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
        	// Get the current value of the variable total from the message data
        	// and update the progress bar.
            int total = msg.getData().getInt("total");
            progDialog.setProgress(total);
            if (total <= 0){
                dismissDialog(typeBar);
                progThread.setState(ProgressThread.DONE);
            }
        }
    };

    // Inner class that performs progress calculations on a second thread.  Implement
    // the thread by subclassing Thread and overriding its run() method.  Also provide
    // a setState(state) method to stop the thread gracefully.
    
    private class ProgressThread extends Thread {	
    	
    	// Class constants defining state of the thread
    	final static int DONE = 0;
        final static int RUNNING = 1;
        
        Handler mHandler;
        int mState;
        int total;
       
        // Constructor with an argument that specifies Handler on main thread
        // to which messages will be sent by this thread.
        
        ProgressThread(Handler h) {
            mHandler = h;
        }
               
        @Override
        public void run() {
            mState = RUNNING;   
            total = maxBarValue;
            while (mState == RUNNING) {
            	// The method Thread.sleep throws an InterruptedException if Thread.interrupt() 
            	// were to be issued while thread is sleeping; the exception must be caught.
                try {
                	// Control speed of update (but precision of delay not guaranteed)
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Log.e("ERROR", "Thread was Interrupted");
                }
                
                // Send message (with current value of  total as data) to Handler on UI thread
                // so that it can update the progress bar.
                
                Message msg = mHandler.obtainMessage();
                Bundle b = new Bundle();
                b.putInt("total", total);
                msg.setData(b);
                mHandler.sendMessage(msg);
                
                total--;      // Count down
            }
        }
        
        // Set current state of thread (use state=ProgressThread.DONE to stop thread)
        public void setState(int state) {
            mState = state;
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
    	MenuInflater inflater = getMenuInflater();
    	inflater.inflate(R.menu.menu_grabar, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.OpcGrabar:
            	 typeBar = 0;				  			
                 showDialog(typeBar);				              	  			                	
				 Intent siguiente=new Intent(Promesa.this, GestionClientes.class);
           	  	 siguiente.putExtra("id_cliente",id_cliente);
           	  	 final TextView pnombres=(TextView)findViewById(R.id.lblNombre);
           	     siguiente.putExtra("datos",id_cliente+ " " + pnombres.getText());           	  	 
           	     startActivity(siguiente);			
            	 return true;           
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
