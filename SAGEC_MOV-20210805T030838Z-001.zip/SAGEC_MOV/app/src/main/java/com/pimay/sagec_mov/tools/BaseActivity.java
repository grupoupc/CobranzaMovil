package com.pimay.sagec_mov.tools;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.Log;
import android.view.Window;

/*import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;*/

import java.io.IOException;



public class BaseActivity extends Activity {
	
	protected SharedPreferences prefs = null;
	protected LocationManager locationManager;
	protected static final long MINIMUM_DISTANCE_CHANGE_FOR_UPDATES = 0; // in Meters
	protected static final long MINIMUM_TIME_BETWEEN_UPDATES = 0; // in Milliseconds
	protected LocationListener locListener = new MyLocationListener();
	public String longitud = "";
	public String latitud = "";
	Handler_sqlite helper=null;
	protected static final int BACK_FROM_GPS_ACT = 1;

	public String getBatterLevel(){
		String batteryLevel = "000";
		IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		Intent batt= getApplicationContext().registerReceiver(null,filter);
		if (batt != null) {
			int rawlevel = batt.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
	    	int scale = batt.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
	    	int level = -1;
	    	if (rawlevel >= 0 && scale > 0) {
	    		level = (rawlevel * 100) / scale;	    		
	    	}
		    batteryLevel = "00" + level;
		    batteryLevel = batteryLevel.substring(batteryLevel.length() - 3,batteryLevel.length());
		}
		return batteryLevel;
	}	
	/*public String etIpRemota() {
		String data = httpGetData("http://www.infosistema.comuf.com/sigac.php");
		String Url= "";
		JSONArray ja=null;
		if (data.length()>10){         	
			ja=new JSONArray(data);
			Url=ja.getString(0);	
		}		
		return Url; 
	}	*/
	public String getIP(){		
		String pURL="";		
								
		//pURL="192.168.1.33:8081";
		helper= new Handler_sqlite(this);
		helper.abrir();
		helper.leerURL();
		pURL="http://181.66.100.142";
		if (helper.urlsrv!=null){
			pURL=helper.urlsrv;
		}
		//helper.urlsrv
		helper.cerrar();
		Log.d("Response HTTP Threads","URL envio: "+pURL);
		/*
		if (pURL==""){
		
			pURL="192.168.1.33:8081";
			JSONArray ja=null;		
			String data = httpGetData("http://www.infosistema.comuf.com/sigac.php");
	     	Log.i("LocAndroid Response HTTP Threads","URL envio: "+"http://www.infosistema.comuf.com/sigac.php");			        
	         if (data.length()>10){
	         	try {
					ja=new JSONArray(data);
					pURL = ja.getString(0);				
					Log.i("LocAndroid Response HTTP Threads","Valida envio: "+"http://"+pURL);				
					Log.i("LocAndroid Response HTTP Threads","Finalizo Validacion: "+"http://"+pURL);
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					pURL="192.168.1.33:8081";
					e.printStackTrace();				
				}         	
	         	Log.i("LocAndroid Response HTTP Threads","URL envio: "+"http://"+pURL);
	         }
		}*/
         return pURL;
	} 	
    public String httpGetData(String mURL){
    	String response="";
    	mURL=mURL.replace(" ","%20");
    	Log.d("Response HTTP Threads","Ejecutando: "+mURL.toString());
    	HttpClient httpclient = new DefaultHttpClient(); 
    	Log.d("Response HTTP Threads","Ejecutando");
    	HttpPost httppost=new HttpPost(mURL);
    	Log.d("Response HTTP Threads","Ejecutando");
    	try {
    		Log.i("Response HTTP Threads","Ejecutando get");
    		ResponseHandler<String> responseHandler=new BasicResponseHandler();
    		response = httpclient.execute(httppost, responseHandler);
    		Log.i("Reponse HTTP",response);
    	} catch (ClientProtocolException e){
    		Log.d("Reponse HTTP ERROR 2",e.getMessage());
    	} catch (IOException e){
    		Log.d("Reponse HTTP ERROR 2",e.getMessage());
    	}
    	return response;
    }
	/** Obteniendo el numero de celular  */
    @SuppressWarnings("unused")
    public String getIMEI(){
    	TelephonyManager tm = (TelephonyManager)
    	getSystemService(this.TELEPHONY_SERVICE);
    	String imei = tm.getDeviceId();
    	return imei;
    	}
	@SuppressWarnings("unused")
	public String getPhoneNumber(){
		TelephonyManager mTelephonyMgr;
		mTelephonyMgr = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		String mblNumber = mTelephonyMgr.getLine1Number();		
		/*  TelephonyManager mTelephonyManager;
		  mTelephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);*/ 
		  return mblNumber;
		}
    /** Called when the activity is first created. */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		prefs = getSharedPreferences("SciPref",Context.MODE_PRIVATE);
		locationManager  = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		//locationManager.requestLocationUpdates( LocationManager.GPS_PROVIDER, MINIMUM_DISTANCE_CHANGE_FOR_UPDATES, MINIMUM_TIME_BETWEEN_UPDATES, locListener);
		//if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
		//	createGpsDisabledAlert();
		//}
		//getCurrentLocation();
    }
    
    public boolean checkGPS(){
    	if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
    		createGpsDisabledAlert();
    		return false;
    	}else{
    		return true;
    	}
    }
    
	public void createGpsDisabledAlert(){  
		AlertDialog.Builder builder = new AlertDialog.Builder(this);  
		builder.setMessage("Tu GPS est� desactivado, por favor act�valo!")  
		     .setCancelable(false)  
		     .setPositiveButton("Activar GPS",  
		          new DialogInterface.OnClickListener(){  
		          public void onClick(DialogInterface dialog, int id){  
		               showGpsOptions();  
		          }  
		     });
		AlertDialog alert = builder.create();  
		alert.show();  
	}
	
	public void showGpsOptions(){
        Intent gpsOptionsIntent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);  
        startActivityForResult(gpsOptionsIntent, BACK_FROM_GPS_ACT);  
    }
	
	
	public boolean getCurrentLocation(){
		if(!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
			return false;
		}else{

			locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, MINIMUM_DISTANCE_CHANGE_FOR_UPDATES, MINIMUM_TIME_BETWEEN_UPDATES, locListener);			
			Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);			 
			if (location != null) {
				longitud = "" + location.getLongitude();
				latitud = "" + location.getLatitude();
				return true;
			}else{
				locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, MINIMUM_DISTANCE_CHANGE_FOR_UPDATES, MINIMUM_TIME_BETWEEN_UPDATES, locListener);
				location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
				if(location != null){
					longitud = "" + location.getLongitude();
					latitud = "" + location.getLatitude();
					return true;
				}else{
					return false;
				}
			}			
		}
	}
	
	public String getCellId(){
		TelephonyManager telephonyManager = (TelephonyManager)getSystemService(Context.TELEPHONY_SERVICE);
		GsmCellLocation cellLocation = (GsmCellLocation)telephonyManager.getCellLocation();
		String networkOperator = telephonyManager.getNetworkOperator();
		String mcc = networkOperator.substring(0, 3);
		String mnc = networkOperator.substring(3);			      
		int lac = cellLocation.getLac();
		int cid = cellLocation.getCid();
		return mcc+":"+mnc+":"+lac+":"+cid;
	}
    
	private class MyLocationListener implements LocationListener{

		@Override
		public void onLocationChanged(Location location) {
			if (location != null) {
				longitud = "" + location.getLongitude();
				latitud = "" + location.getLatitude();				
			}
		}

		@Override
		public void onProviderDisabled(String provider) {
			// TODO Auto-generated method stub			
		}

		@Override
		public void onProviderEnabled(String provider) {
			// TODO Auto-generated method stub			
		}

		@Override
		public void onStatusChanged(String provider, int status, Bundle extras) {
			// TODO Auto-generated method stub		
		}
		
	}    
    
	protected void savePreferences(String key, String value){
	    SharedPreferences.Editor editor = prefs.edit();
	    editor.putString(key, value);
	    editor.commit();
	}
	
    
}